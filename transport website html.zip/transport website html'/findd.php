<html>
    <head>
        <style>
            .table{
                border-collapse: collapse;
                margin: 25px 0;
                font-size: 0.9em; 
                border: 1px solid black;
            }

            .table, tr{
                background-color: #dddddd;
                color: black;
                text-align: left;
            }

            th{
                background-color: #009879;
                color: #ffffff;
                font-weight: bold;
                text-align: left;
            }

            .table, th, td{
                padding: 12px 15px;
            }

            .table, tr:nth-of-type(odd){
                background-color: #f3f3f3;
            }
            
        </style>
    </head>
    <?php
    $servername='localhost';
    $username='root';
    $password='';
    $dbname="project_find";

    $conn = mysqli_connect($servername,$username,$password,$dbname);
    if(!$conn){
        die("Connection failed: ". mysqli_connect_error());
    }
    // echo "Connected successfully";
    
    $state = $_GET['state'];
    $sql="select * from find_us where state = '$state'";
    $result = mysqli_query($conn, $sql);
    
    if(mysqli_num_rows($result) > 0){
        echo "<table class='table'><tr><th>id_no</th><th>contact_person</th><th>city</th><th>state</th><th>phone_no</th></tr>";
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr><td> ". $row["id_no"]. "</td><td >". $row["contact_person"]. " </td><td>".$row["city"]. " </td><td> ".$row["state"]. " </td><td>".$row["phone_no"]. " </td></tr>";
        } 
        echo "</table>";
    } else{
            echo "0 results";
        }

    mysqli_close($conn);
    ?>
</html>