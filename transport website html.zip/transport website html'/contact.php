<?php
    $servername='localhost';
    $username='root';
    $password='';
    $dbname='project_contact';

    $conn = mysqli_connect($servername,$username,$password,$dbname);
    if(!$conn){
        die("Connection failed: ". mysqli_connect_error());
    }
    // echo "Connected successfully";

    $name=$_GET["name"];
    $company=$_GET["company"];
    $phone=$_GET["phone"];
    $consignee=$_GET["consignee"];
    $destination=$_GET["destination"];
    $gst=$_GET["gst"];

    $sql = "insert into contact_us(name, co_name, phone_no, consignee_location, destination, gst_no) values('$name', '$company', '$phone', '$consignee', '$destination', '$gst')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
      } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
      }
    mysqli_close($conn);
?>