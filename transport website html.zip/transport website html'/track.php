<html>
    <head>
        <style>
            .table{
                border-collapse: collapse;
                margin: 25px 0;
                font-size: 0.9em; 
                border: 1px solid black;
            }

            .table, tr{
                background-color: #dddddd;
                color: black;
                text-align: left;
            }

            th{
                background-color: #009879;
                color: #ffffff;
                font-weight: bold;
                text-align: left;
            }

            .table, th, td{
                padding: 12px 15px;
            }

            .table, tr:nth-of-type(odd){
                background-color: #f3f3f3;
            }
            
        </style>
    </head>
<?php
    $servername='localhost';
    $username='root';
    $password='';
    $dbname='project_tracking';

    $conn = mysqli_connect($servername,$username,$password,$dbname);
    if(!$conn){
        die("Connection failed: ". mysqli_connect_error());
    }
    // echo "Connected successfully";

    $track=$_GET["track"];
    $sql = "SELECT * FROM tracking WHERE tracking_no ='$track'";
    $result = mysqli_query($conn, $sql);
    
    if(mysqli_num_rows($result) > 0){
        echo "<table class='table'><tr><th>id_no</th><th>tracking_no</th><th>pickup_location</th><th>drop_location</th><th>present_location</th><th>estimate_reaching_date</th></tr>";
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr><td> ". $row["id_no"]. "</td><td >". $row["tracking_no"]. " </td><td>".$row["pickup_location"]. " </td><td> ".$row["drop_location"]. " </td><td>".$row["present_location"]. " </td><td>".$row["estimate_reaching_date"]. " </td></tr>";
        } 
        echo "</table>";
    } else{
            echo "0 results";
        }
  mysqli_close($conn);
?>
</html>